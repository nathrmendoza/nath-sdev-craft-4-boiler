-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_qknmsqxlqigjulnwiqruusfkztjsphaobuhi` (`ownerId`),
  CONSTRAINT `fk_camyshlddiqahmcgemlqupokstsugljoxntd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qknmsqxlqigjulnwiqruusfkztjsphaobuhi` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vdjhfspdijgdwbwwtoafbxhtfbdxqhopbqfq` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_jfzkhhkurmwfetpwgfbxcjeuhrkgafcbhkbh` (`dateRead`),
  KEY `fk_winiquoglnreqnzibzogmhzbudxwllcuwxmh` (`pluginId`),
  CONSTRAINT `fk_qucuyqjyahhmlzeoorepucnlpwkpcffuyvup` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_winiquoglnreqnzibzogmhzbudxwllcuwxmh` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jzzvqkdydtrpulbsbefefzhlzcxketjkoyya` (`sessionId`,`volumeId`),
  KEY `idx_ruggwopawetpbbiujpgyuvdsjgrulidyvicn` (`volumeId`),
  CONSTRAINT `fk_gftqhwlogfqryfzjzkjzwfxjvpsfmhakvuwu` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vcjzsumbggrnaizpgjmshmirnutjazwpnmuw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qvqszfycefubwulsvsoevjnmhxjojduhenap` (`filename`,`folderId`),
  KEY `idx_kuvnaiirsitxnupjtoitrwgqpztvhuaafjlf` (`folderId`),
  KEY `idx_nvgelzajvhoqbvmjosajqijvbctueqagjixg` (`volumeId`),
  KEY `fk_rcxiwibpengtdvmncykzucllyqxkixndjkjh` (`uploaderId`),
  CONSTRAINT `fk_enaqzecfxjcyumjdnftwmxrwxjngxujgrsiz` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rcxiwibpengtdvmncykzucllyqxkixndjkjh` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vjnxeqjatvtshkqjidrntugzqxnkhmcqsfsa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yhushrrcsdlluvljyzbolhcbfhswcbmnhglh` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pdtoyycojlgvzbrfmpoylmueirupfzbrbrki` (`groupId`),
  KEY `fk_ejmmettyiobnyxupvkjutxbgwjqpbqhpzbkj` (`parentId`),
  CONSTRAINT `fk_ejmmettyiobnyxupvkjutxbgwjqpbqhpzbkj` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gbpjgtgpbluxapqdqatuvgrjohlhwhxdhgsf` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zhdcfuqjrbvnsmrwhaqexrdwctorktfwdoiq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kfduosexvaogqezhkgkwmsmttmbvdmmhbbei` (`name`),
  KEY `idx_wdafufbzyljvaxqccairgzxbstnatealtvrb` (`handle`),
  KEY `idx_qldibylifofqulgkilnoxxdqifobuwphhmmd` (`structureId`),
  KEY `idx_rjpszixlqvqhkwkcriugpmxsrwdxsyigxonm` (`fieldLayoutId`),
  KEY `idx_yumthkmqirdfxpvjbakpucgmxeqonbhaurla` (`dateDeleted`),
  CONSTRAINT `fk_mwiarghrqgznezpkjrnsaehhwfprjuysjwxm` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qxoecitmeopxgtnirpcpuduqijcxwioxkbgb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nkzkldzriaalrasjoqecofsqqsgqilqxyvpa` (`groupId`,`siteId`),
  KEY `idx_rujdoudtccqbnkcebzvtekhewcoibbmflenc` (`siteId`),
  CONSTRAINT `fk_ueaidsrlepomwqzobnwmkodwvdtaampkqodn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zozotuoeljphknnsqyaepfcjyerrltwletnh` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_sxvchaumblfetymsvtkndartusmeguxrhtdv` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_cekkmmgdzposjzhmnwhuwtjqtngrkbcyimww` (`siteId`),
  KEY `fk_xckvyzrzrerqlousandasgscjgamjynvfsak` (`userId`),
  CONSTRAINT `fk_cekkmmgdzposjzhmnwhuwtjqtngrkbcyimww` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nssslqleperhitlszzmsyqltrnalhxhscayw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xckvyzrzrerqlousandasgscjgamjynvfsak` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_uedirgdrmncfbquozrmbpdcpauiadhnbptkh` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_kfandfgkpqgkadyxneefigtvljlwcizmzxnv` (`siteId`),
  KEY `fk_jvkswnslmdqohefoepgjbayzvxokptlildew` (`fieldId`),
  KEY `fk_ainptvudqnbuirjhjyhevpzocigothdrwltn` (`userId`),
  CONSTRAINT `fk_ainptvudqnbuirjhjyhevpzocigothdrwltn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_jvkswnslmdqohefoepgjbayzvxokptlildew` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kfandfgkpqgkadyxneefigtvljlwcizmzxnv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rwfpzjswivvkohxolxywogmrmizvjvstjcca` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_text_gelggtgx` text,
  `field_fullText_ycuvybxe` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gtnsxlvwhluysemwlvpzzftkokczzucsrbni` (`elementId`,`siteId`),
  KEY `idx_zhxfdyyytwcdvnlbnnbpqyqpgoaoxupmvzoo` (`siteId`),
  KEY `idx_mkjwifgwpsdchjujjeiiiudsltfpsnlwrhqz` (`title`),
  CONSTRAINT `fk_fuhqpystgstxxltromqdxlfnwkdmnnkpwaff` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zdfoarobnrhwjylxtqrxgktwwbvyxfxamsqx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_curjwofkdzzgxjxjonifarwabpmhommwzkdw` (`userId`),
  CONSTRAINT `fk_curjwofkdzzgxjxjonifarwabpmhommwzkdw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hbsjilrleplbubkjlftdzmtemndyeawkazop` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_wsvcrpeyaxecrzzwnsviapaecrqmishaakah` (`creatorId`,`provisional`),
  KEY `idx_vabdnykkbrqonmxvxztnotbizpggjgwermxf` (`saved`),
  KEY `fk_fsezzhfqrlrzfmtvkrhbnvokfrczfwpeimmg` (`canonicalId`),
  CONSTRAINT `fk_fsezzhfqrlrzfmtvkrhbnvokfrczfwpeimmg` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qcnafrgijjoezpbjkronzzbwjrpahqxnonvu` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_aohthnrfqhpvhsdckbczsnmnhqoqcocdcbby` (`elementId`,`timestamp`,`userId`),
  KEY `fk_gnyjgqutvswxipkiyfpgfyyxhwfgepsetvns` (`userId`),
  KEY `fk_qofalwqmwypbbhuuijpzfslpbkiwhbknkoel` (`siteId`),
  KEY `fk_upxltodysfimtyxcovbqazwtiziygqzkpgld` (`draftId`),
  CONSTRAINT `fk_gnyjgqutvswxipkiyfpgfyyxhwfgepsetvns` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qofalwqmwypbbhuuijpzfslpbkiwhbknkoel` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_upxltodysfimtyxcovbqazwtiziygqzkpgld` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xdrngpvbulrgldiakwwzooohlakwieylilry` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kpihkquukgeedyhxsujstmaovfmbnktlvqsf` (`dateDeleted`),
  KEY `idx_kzrdrqqqkcnrevgiqqrourtxkprleygbdnss` (`fieldLayoutId`),
  KEY `idx_sgkqqkwcbvbnjjoalnygzpjcgpmbramnxduh` (`type`),
  KEY `idx_yprtehoygdrfgfmkkjiurcvpvnksqvtolsai` (`enabled`),
  KEY `idx_rqlxfwyvmpybmneacxywpdwasdfkxgtlhuah` (`canonicalId`),
  KEY `idx_kvzdtdqtyxdehbchaxesbunhzchxgefqzsri` (`archived`,`dateCreated`),
  KEY `idx_hkxntabdnddybohxodwgbnhczussglkfwbmz` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_wwecqcfnjepxryoqfzqvkhvzozmxjlcxfizw` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_oxrxexihqcopvqtftildfbdvqtayilffvedq` (`draftId`),
  KEY `fk_jpgikbciayenzojdndytecswxjhhmehbownd` (`revisionId`),
  CONSTRAINT `fk_cszvmaqjvokcqoyvhodjrfsrhxlybfpgczra` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jpgikbciayenzojdndytecswxjhhmehbownd` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oxrxexihqcopvqtftildfbdvqtayilffvedq` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qmagziybcmuaacqpfztkrdqsbreksrtucrhj` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fzkcghymvesvbzrxrxdwyfhtxhtakjtnllzx` (`elementId`,`siteId`),
  KEY `idx_tsdvucduajduzwgahoabokzvdhqycncgelpq` (`siteId`),
  KEY `idx_aobiovrxmwqsevslpnefqvodruzstgnqeqpp` (`slug`,`siteId`),
  KEY `idx_trhvsvwlgykxqwyvwtkorxxsklkccojfjmvz` (`enabled`),
  KEY `idx_efapzoaaxxetkpxgxsowgmxtvpysnodijcki` (`uri`,`siteId`),
  CONSTRAINT `fk_ndnrtvpqqucqqlparatfrlfsakecplshzbxf` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oyyggnjajlklxaelwkpvsnonxaahiaxasekk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_snbmmcggwuijcexkoipajebpofhvrlgurywe` (`postDate`),
  KEY `idx_wvgjdyrazbbnqfotxaoenlahmqxhqawfwgln` (`expiryDate`),
  KEY `idx_cwyhnymelxqwfubohshlwrfagqycucameazt` (`authorId`),
  KEY `idx_dzbwqcsxybdfenrateuptzlihcqjncuxyycn` (`sectionId`),
  KEY `idx_pxcjnjuotejubntogpkvbzkjocxirxnjypab` (`typeId`),
  KEY `fk_azsegxtxsijmyrjttgeahzwcmzvhujkrfuqo` (`parentId`),
  CONSTRAINT `fk_azsegxtxsijmyrjttgeahzwcmzvhujkrfuqo` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_bziqjmsfwsttnorawibzypyqdfylisunepyy` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dkkimqpjadwzehywlvfgrhabfbvcortlgnzz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oxrmrvushbcoegseigyxnksxrvmqummhooow` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sgwxaykwzjtftvumddauzzzmwborcogqacfa` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qibotdyfoskbigwboofpiqzlriggrgqefkwq` (`name`,`sectionId`),
  KEY `idx_nwwfasxhjmbrjbzjmtasrsfvzlaoggvlkwky` (`handle`,`sectionId`),
  KEY `idx_zvzeowydbmsgsgsvzrndixeauuvuodlchfcw` (`sectionId`),
  KEY `idx_frxsjezylozfahdyewjepgxgxkqschfkiayq` (`fieldLayoutId`),
  KEY `idx_faxwxxdrfvvdronoxznfcmlcvcdtvnzgrome` (`dateDeleted`),
  CONSTRAINT `fk_ajevbeengsvgqfslebepxytaqhyzpfwwmddm` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_otoyeoqaylgywhkdjtacsxzgthhauydmpjsq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_syrzbbwjlntuzwmjawehqaagqidsghdfykop` (`name`),
  KEY `idx_enliaiidbqxayprwlbpzwthxcroolyqkhrna` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ycqvpyxbchzdcxkwhvrgzezbklgtbeyltuva` (`layoutId`,`fieldId`),
  KEY `idx_abmjqutyhhnsuuyavazwosdgghrzapkcbjhn` (`sortOrder`),
  KEY `idx_wzipkpxnhpgqxkyhznlkttilpekjyqywqyst` (`tabId`),
  KEY `idx_pibednlxwjgllytxkurnyunkoyxexkmltepe` (`fieldId`),
  CONSTRAINT `fk_eocempsqiuogdofnuujmgbitortaajuvjsxm` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tyglonnlxggjmewxqbmttaxudpjfpebdpxmb` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xwzvuisqphmibprpsphdacmaydtvkstkqqyw` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_spsqhupgsuzbmascyaphvzwauhjayxsijcpo` (`dateDeleted`),
  KEY `idx_rvwnuqsqoedukdkgtcbdigpqxovkgvtyaemj` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ujdvpquujvfkdqzivpkrdtstgeikjfxdgffg` (`sortOrder`),
  KEY `idx_ikqqhshezdrfwzweecwacfdvznpoezghykol` (`layoutId`),
  CONSTRAINT `fk_bkypnvkzhacgyectkcrwrjsswzqtycwwgsnm` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wlmbbohhjsthuxftupiknvheqvoxcilherpv` (`handle`,`context`),
  KEY `idx_mebpyrzqslfzweehmuvlexhqemvwsiqtchwh` (`groupId`),
  KEY `idx_tpzerqhnloxiuaaayjpbfszbtudygyujawzg` (`context`),
  CONSTRAINT `fk_rwtyoxfvifnihoowxcqqoxzhsgdphnrfnjym` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rujgpgiltuulgpukkdfgcaqbypmqixjevbcu` (`name`),
  KEY `idx_ocpehtysixoyxtofqnszdduvqwiuicbwifkm` (`handle`),
  KEY `idx_acnrytvbmuzxmviulwjlbgmlnrnmomobizyo` (`fieldLayoutId`),
  KEY `idx_lsqgswhpuivrthoybyknffsskaptodhhlrdy` (`sortOrder`),
  CONSTRAINT `fk_ikxvusigfadvcfzxrbmtomfnxbwuhthfjugm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vpebefqrtfilkcfpzizbewfcpunigpjcapst` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kwyxukjcvsafixowdiogpwafdfzvxeivmkvg` (`accessToken`),
  UNIQUE KEY `idx_nbksjjvgfpfdgrcwavwrymtuicsrithbfwvo` (`name`),
  KEY `fk_ixjinnsjhituwobcmovrfsimudsuewkplsqo` (`schemaId`),
  CONSTRAINT `fk_ixjinnsjhituwobcmovrfsimudsuewkplsqo` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xvejedyogtongujgnovarftpzyjnwxnoekfb` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gmshskxmmxffwsjycsxlzvdywownivpxckmn` (`name`),
  KEY `idx_vzwwxyymyucrlajykhnozjrnzevbdctmhefg` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yhnrjagbbzdlrairincgjapwviowpdwjcren` (`primaryOwnerId`),
  KEY `idx_djdzkwurtvsjoxcvzwtrbrtqcbyaxxyaslvh` (`fieldId`),
  KEY `idx_kowpapusnygnpgaprrirclipcgfqejvjjizj` (`typeId`),
  CONSTRAINT `fk_eluvzderoybsoppluhhkjilqzgeozinfgnqc` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lxsumffnevhmfxvxsrvdajcbmawqbzwfsllv` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pmcmugffpsumjnambwerwtgjotpkvjmuqwwh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdidfxinveluvrbnhhwqmthgyxvzkgldxuan` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_horsepgqbrkqrtegbenxonxrftoqszrdaefa` (`ownerId`),
  CONSTRAINT `fk_horsepgqbrkqrtegbenxonxrftoqszrdaefa` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kscqfcpjkacymbmvhkzkealoluqplaqovytd` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cwmaotbberflkujnwxwcrzfqkvkonrypjsxt` (`name`,`fieldId`),
  KEY `idx_nxbzfgzvztqiryrgfkvcwfpwqzymhnfzztte` (`handle`,`fieldId`),
  KEY `idx_ptcjjepszegtslxvysjvkqlbuzhgwczxxxuo` (`fieldId`),
  KEY `idx_pusvorygxfdkihqnbgbtfvcodxiyuopxkypm` (`fieldLayoutId`),
  CONSTRAINT `fk_apcrioirudedmqevyogzzbxepxsulirqawjk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ikdjhzyouvqkfxxaxgeoblupogicjnezwyoj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_components`
--

DROP TABLE IF EXISTS `matrixcontent_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixcontent_components` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_hero_heading_qnetthbg` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gcvkvhxmuglbwrflsanpjigusdnoeqxiclmq` (`elementId`,`siteId`),
  KEY `fk_ttalwoqkmmiuitqoukwyjtckfmmxhpusvfao` (`siteId`),
  CONSTRAINT `fk_rkxrtiuqnltzeogoxkymmrykjzfxmduyabyu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ttalwoqkmmiuitqoukwyjtckfmmxhpusvfao` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xhxrgdfwbretdcziffspkpihsqlntjslcyrh` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tqvvagwfoxblzgiqpqfxlobmqawfhpqwrijs` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_ybdmkvucdwyhbgrkkplpkyijqawwcvwzsiqe` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_gfibecatsmxtajkgefcecoxnalqyxghbqsxv` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qpdhgmngipzrvnuvuwvpsacxswvgkafovyhl` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_dkpndezfrgtoednouiwoopicfursnjacqdzg` (`sourceId`),
  KEY `idx_xrlylrraglrkuovsayswxpiqvknehsclydkf` (`targetId`),
  KEY `idx_nykvbpzhmoczijgugyheugiriszyvzxsqdcr` (`sourceSiteId`),
  CONSTRAINT `fk_atmzypvlheulwnnluxtdstcdxdmlftvpvbhm` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hfduqzdbcfwumfopzolexnmwljvjuxxyktww` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hvytramewdhtnbbfdskhwvwaxjjjlfqprfjk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_abfqivxapyhaglgptylfwkzoxgmyclotddzr` (`canonicalId`,`num`),
  KEY `fk_dzilnzrntzlulzghvhifttfnowyntsqzszea` (`creatorId`),
  CONSTRAINT `fk_dzilnzrntzlulzghvhifttfnowyntsqzszea` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_khgsulrhxkmcnooelnxgoqkpidwdhzdmbizu` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_rvfnproerhtujcholhuyvtdqkknivygoifbs` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kgftojuuugcyqdruqibsavpgjdmkhdotfntt` (`handle`),
  KEY `idx_wayykfauwfllgqhhwlrcgrsrjdtgiqrlsioq` (`name`),
  KEY `idx_sopfjkpgwpdurcbaiwaxxrbebtbfxuhsmbdf` (`structureId`),
  KEY `idx_urahkspcpeosrhwzetxgzhyuhahzfumioxga` (`dateDeleted`),
  CONSTRAINT `fk_fglzueclfwhhobhvfgdpvhtygvomtjqxiccy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kwqrgbzdvxuacnkakrpweztlmtxpfzxzngom` (`sectionId`,`siteId`),
  KEY `idx_lgcuafjlokoafcqscbzxxvivdaafbstoktcq` (`siteId`),
  CONSTRAINT `fk_emaxzkesaipezgrkmdcfonhcgtsglwrzeyto` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mpsktofwvnithexxdjzalzyrwfklmtzjvvab` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gfkwadvcandhkjrubrutbbrlnhblhokgqefa` (`uid`),
  KEY `idx_mqznmjdwbkldvgiovosnlmqeccszcfryjgke` (`token`),
  KEY `idx_eomobzzerpjokqjjsdfwkvnqxgtrvpclmuul` (`dateUpdated`),
  KEY `idx_htwomgweetnoyzgmclyxexervgxfkrhcmory` (`userId`),
  CONSTRAINT `fk_rathhcnzlirftjeavsucelemmnrwrvjxtmyw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tkjxnpznzuzgliolpfiducoolaznkpsvnqgb` (`userId`,`message`),
  CONSTRAINT `fk_qalhgahabgfrgnfrsscwebbleujobfemzitx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mzgztfugtrbgezthbcupzqxwkfywxsgtpabl` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_escweajsgyqabgxkrpbygcqjvwhgiaursonm` (`dateDeleted`),
  KEY `idx_kldongzixweczknoyalzptwpplcrkpupvxqg` (`handle`),
  KEY `idx_ckiotnlvoznemikwhjbaxgmuaoxftuqrlpta` (`sortOrder`),
  KEY `fk_ojdpdfqqudzwgxwufgungobbhicykzsiagjo` (`groupId`),
  CONSTRAINT `fk_ojdpdfqqudzwgxwufgungobbhicykzsiagjo` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_otdnxdurregvyetsavnowfucxvwilgqtwmne` (`structureId`,`elementId`),
  KEY `idx_pvfjainxgqbbaecudnyydkdsbxatesxtelae` (`root`),
  KEY `idx_iglphcnwipfatqobkxbhumflwxyucrghhika` (`lft`),
  KEY `idx_ubxnonmtemwiaggvcdhkgtgklmkqckgqjgsq` (`rgt`),
  KEY `idx_pbpdexywphcpsmfsbwqihdyurghyxmbnovxo` (`level`),
  KEY `idx_mwlsxycmsbqazcwsavxamjrmtqaxtjfbvoop` (`elementId`),
  CONSTRAINT `fk_gdhpluznriplqqawfqdujryicdpnxzgzamlu` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xzsliyrglhtytoggpkzldmcfnhinnyyiiauu` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_skpitlxnddmpoerodaudtdsvjqnsomxmxowt` (`key`,`language`),
  KEY `idx_pnrvtqvqpuuzxmkpclmvzntrvubdikucphqk` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dveqpalpksmizorbezpwjoqwnarqvnjcvcxk` (`name`),
  KEY `idx_mzepedthfsrfibnqqgbfpcwenbqdynlxecvw` (`handle`),
  KEY `idx_gvinnnrdtvwliusmlhzvgifptxkqwbnvherk` (`dateDeleted`),
  KEY `fk_ysllwenxsvurfgvcsfxxwomqxbgmpiwaomsn` (`fieldLayoutId`),
  CONSTRAINT `fk_ysllwenxsvurfgvcsfxxwomqxbgmpiwaomsn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mwgzsupsiqmihjpmsjsczjendiiagaehouyx` (`groupId`),
  CONSTRAINT `fk_dhxrohvcurvymolxftupbatpoixnneszauur` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hpnmnzpwnqiiajvxijanlghycbqblzrkdesl` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jalehszirkomsiwzivweeossuslcregsyciv` (`token`),
  KEY `idx_svyswazkxnzblwmlcpynuifssxvlskcnnmrk` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uaoxycbuuurcleqhqmxztdpxqcnfyruassns` (`handle`),
  KEY `idx_ojmahtpswvrchvfhmxmcxmqmhmdddjcpolas` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yjgdfoiwgxqcjcakvxplkkcfacrbxsiqdngh` (`groupId`,`userId`),
  KEY `idx_qswrdhxreebhozsqdmjljpzuesaeifndszdf` (`userId`),
  CONSTRAINT `fk_cqdbgonvzdyxffccdsjqhkgyjlzxgyvvjwsj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nomgscgosyfgrqzvslwtcgbiatssqcgdnmfe` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ieidksgncnndhulscztpvpkuvwloffcayklw` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vfnobwzxdorwdtpgfmzlbinvwqdxqtvtkzgt` (`permissionId`,`groupId`),
  KEY `idx_wratnnlxyypqssbyclllrtrftmhdjdscebhb` (`groupId`),
  CONSTRAINT `fk_djtgimrejimbqvcxieasrcmawymymyqxxsoe` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hoorfeyfiltyxdahtsznpadljspxdigubobl` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bqeueeggoxnyyegeomhoixqlkdvuyshhwtzb` (`permissionId`,`userId`),
  KEY `idx_ycukothdgrjdukkfsealuztfiozfawvrglny` (`userId`),
  CONSTRAINT `fk_jdgyncvhuernhsyyhfdpvklhffdkyedoirvv` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zvoihmepxtacylumcscwosrhwrrxufewzxwz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_mraziruciiphrmxvnoslorjutnsdzbxalxjo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lzkcelytctyokijbmevicwbpxuchlrthcacb` (`active`),
  KEY `idx_yxgszrshxmxufkbqktpccrvfrftzzrcpbdqd` (`locked`),
  KEY `idx_iblnbjwmmwdeohxaetcqxurmrkzmfddjrelf` (`pending`),
  KEY `idx_fbqmndcbqmnhjblaqrjnagodnkdjoblbetxb` (`suspended`),
  KEY `idx_xrdcradiifxeffwfjbqzjjrmjkcaoxloquad` (`verificationCode`),
  KEY `idx_iojbnocvgxpaaoxrfvkohppfdevzrmavkzib` (`email`),
  KEY `idx_pzowwcajfjocsecpgxtbyqndpsrygdmqltrs` (`username`),
  KEY `fk_fcrwkulgzutdnibkqkbdnoiqtwazwihgcfzt` (`photoId`),
  CONSTRAINT `fk_cjuhhbkdqvaoldfqtgmzsmbstuwrzeqoeioo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fcrwkulgzutdnibkqkbdnoiqtwazwihgcfzt` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dhrtogyallmbuqotmhhoqbcuniogcsxnyepl` (`name`,`parentId`,`volumeId`),
  KEY `idx_sdcouwdbrkbthehszwgdceolqethrmdckmdw` (`parentId`),
  KEY `idx_yqqiwqctywzwtacggxqxvozjdcyswckgsopd` (`volumeId`),
  CONSTRAINT `fk_gqdrmbxcnzceqgwuzfiosixeooabmvxqoxvy` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nmibwuqqfuiwftqqqapfvlovzqfsyrmotvdd` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usauadaxbjmuttngeqppbwozcgzdbwqftmom` (`name`),
  KEY `idx_alpowzelkamevhczktflalbiglvykugneboa` (`handle`),
  KEY `idx_rcbzmuaatsxtqkzgflpidebcaaefmssyckec` (`fieldLayoutId`),
  KEY `idx_vvjaxkxivkdwpmofwdwqxpnrrbkqucbixunj` (`dateDeleted`),
  CONSTRAINT `fk_cgrrgxueooktrbvpxsctzxigzbwietyszxwk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_euycbkyhcashbhunqebnoevlhwtsqnqeizqb` (`userId`),
  CONSTRAINT `fk_wxpjtnzkqitwklsgaoxiutbbgehvhtxcuheu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-11 21:38:55
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (6,1,1,1,'1369159.jpeg','image',NULL,1920,1080,343275,NULL,NULL,NULL,'2024-08-11 21:12:20','2024-08-11 21:12:20','2024-08-11 21:12:20'),(9,1,1,1,'1368925.png','image',NULL,2912,1632,7818808,NULL,NULL,NULL,'2024-08-11 21:14:11','2024-08-11 21:14:11','2024-08-11 21:14:11');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (5,1,'postDate','2024-08-11 21:12:29',0,1),(5,1,'slug','2024-08-11 21:12:08',0,1),(5,1,'title','2024-08-11 21:12:08',0,1),(8,1,'postDate','2024-08-11 21:14:16',0,1),(8,1,'slug','2024-08-11 21:13:59',0,1),(8,1,'title','2024-08-11 21:13:59',0,1),(11,1,'slug','2024-08-11 21:15:29',0,1),(11,1,'title','2024-08-11 21:15:29',0,1),(11,1,'uri','2024-08-11 21:15:29',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (5,1,5,'2024-08-11 21:12:09',0,1),(5,1,6,'2024-08-11 21:12:20',0,1),(8,1,5,'2024-08-11 21:14:06',0,1),(8,1,6,'2024-08-11 21:14:11',0,1),(11,1,1,'2024-08-11 21:15:32',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2024-08-11 20:58:49','2024-08-11 20:58:49','f081d5f5-01b5-4b4f-9a43-e047faab3251',NULL,NULL),(3,3,1,NULL,'2024-08-11 21:11:08','2024-08-11 21:37:39','83c268bb-4f17-41ee-80c4-75e412f75e71',NULL,NULL),(4,4,1,NULL,'2024-08-11 21:11:14','2024-08-11 21:11:14','407abbd9-1e07-447e-a120-640b015d9a5f',NULL,NULL),(5,5,1,'This is a slide heading','2024-08-11 21:11:45','2024-08-11 21:12:29','d1382dd4-8c0b-4375-883a-f18f4e2e75d4',NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor fringilla metus mollis sodales. Vivamus egestas urna turpis.'),(6,6,1,'1369159','2024-08-11 21:12:20','2024-08-11 21:12:20','aaa838f5-7222-4f38-b55f-d92447b96f4e',NULL,NULL),(7,7,1,'This is a slide heading','2024-08-11 21:12:29','2024-08-11 21:12:29','385950a7-4843-4cf3-b0c8-02c8f9fefc34',NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor fringilla metus mollis sodales. Vivamus egestas urna turpis.'),(8,8,1,'Another Slide','2024-08-11 21:13:55','2024-08-11 21:14:16','4df19bf0-0eaf-4ba3-95f6-dd06b695017a',NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor fringilla metus mollis sodales. Vivamus egestas urna turpis.'),(9,9,1,'1368925','2024-08-11 21:14:10','2024-08-11 21:14:10','0efdaaac-1e18-4c2b-b96f-4a13a1e8ff28',NULL,NULL),(10,10,1,'Another Slide','2024-08-11 21:14:16','2024-08-11 21:14:16','efdb955f-c2ab-4c51-bfdb-ebcf58621fa9',NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean porttitor fringilla metus mollis sodales. Vivamus egestas urna turpis.'),(11,11,1,'About Us','2024-08-11 21:15:00','2024-08-11 21:37:39','4a4bda2b-8146-4d4f-bc71-f2c0c9fcb9ac',NULL,NULL),(12,13,1,NULL,'2024-08-11 21:15:08','2024-08-11 21:15:08','da514d2b-b1be-4700-a05e-a4bf6fa9cabd',NULL,NULL),(13,22,1,'About Us','2024-08-11 21:15:32','2024-08-11 21:37:39','c83c1a9d-ed39-4138-8a39-efbd608b1896',NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (2,NULL,1,0,'First draft',NULL,0,NULL,1),(3,NULL,1,0,'First draft',NULL,0,NULL,0),(7,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (5,1,1,NULL,'save','2024-08-11 21:12:29'),(8,1,1,NULL,'save','2024-08-11 21:14:16'),(11,1,1,NULL,'save','2024-08-11 21:15:33');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-08-11 20:58:49','2024-08-11 20:58:49',NULL,NULL,'89dfe749-d3d1-4269-aaef-6ed5bbbe100e'),(3,NULL,2,NULL,1,'craft\\elements\\Entry',1,0,'2024-08-11 21:11:08','2024-08-11 21:11:08',NULL,NULL,'f39068e4-3cbf-4638-8c17-a487820ff04e'),(4,NULL,3,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-11 21:11:14','2024-08-11 21:11:14',NULL,NULL,'f6068f2c-14f7-4760-9d27-1b13915bf7f5'),(5,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-11 21:11:45','2024-08-11 21:12:29',NULL,NULL,'a56c4a42-b6b1-449b-b180-6a7ba8fbec5c'),(6,NULL,NULL,NULL,6,'craft\\elements\\Asset',1,0,'2024-08-11 21:12:20','2024-08-11 21:12:20',NULL,NULL,'4cc506d4-ba69-44c7-b6c0-b799c26b4dd9'),(7,5,NULL,1,5,'craft\\elements\\Entry',1,0,'2024-08-11 21:12:29','2024-08-11 21:12:29',NULL,NULL,'b8b29ca6-9b84-4c28-8c93-a13aedc6fbb2'),(8,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-11 21:13:55','2024-08-11 21:14:16',NULL,NULL,'199a150b-2c12-4943-9037-8e0d23dd5377'),(9,NULL,NULL,NULL,6,'craft\\elements\\Asset',1,0,'2024-08-11 21:14:10','2024-08-11 21:14:10',NULL,NULL,'b1cd9579-f2dd-4b51-8787-e0e24047e337'),(10,8,NULL,2,5,'craft\\elements\\Entry',1,0,'2024-08-11 21:14:16','2024-08-11 21:14:16',NULL,NULL,'49db6ad6-4792-4612-a328-3924538a43a8'),(11,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-08-11 21:15:00','2024-08-11 21:15:32',NULL,NULL,'644bbcd8-3006-449a-92ce-fd74bb3892c5'),(12,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:03','2024-08-11 21:15:03',NULL,'2024-08-11 21:15:12','4d79cae5-9f03-4fde-8d63-36bb9762e734'),(13,NULL,7,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-11 21:15:08','2024-08-11 21:15:08',NULL,NULL,'37c2121e-8e85-4d82-bad7-80910583bd59'),(14,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:12','2024-08-11 21:15:12',NULL,'2024-08-11 21:15:14','795d6bbb-401f-465c-be6d-5378ad08a43f'),(15,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:14','2024-08-11 21:15:14',NULL,'2024-08-11 21:15:20','3f599634-e999-4402-84bc-39bbc8be7f67'),(16,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:20','2024-08-11 21:15:20',NULL,'2024-08-11 21:15:23','ec489304-2950-4bdd-bc4f-e348089ef104'),(17,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:20','2024-08-11 21:15:20',NULL,'2024-08-11 21:15:23','5f5c809b-3d28-477a-9c07-38b6b58fddad'),(18,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:23','2024-08-11 21:15:23',NULL,'2024-08-11 21:15:32','2d999670-6162-4dda-88f7-fc71b9009b5c'),(19,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:23','2024-08-11 21:15:23',NULL,'2024-08-11 21:15:32','204eee9d-2e40-454c-9523-c88767d395e0'),(20,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:32','2024-08-11 21:37:39',NULL,NULL,'5baca29e-81a5-49ff-959b-1a4710568880'),(21,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:32','2024-08-11 21:37:39',NULL,NULL,'34365b51-d6db-418e-81bd-7a51da50fa82'),(22,11,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-08-11 21:15:32','2024-08-11 21:15:32',NULL,NULL,'e0b5da1b-ca3d-423f-a677-3e27e91d307a'),(23,20,NULL,4,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:32','2024-08-11 21:37:39',NULL,NULL,'3298be3a-9a2c-41d5-98d3-450fb20f7152'),(24,21,NULL,5,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-11 21:15:32','2024-08-11 21:37:39',NULL,NULL,'c027ba5f-5b3c-443b-b56e-342ee9f27a7c');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2024-08-11 20:58:49','2024-08-11 20:58:49','1bb20b4a-fbdb-4c18-87ae-f5114a56ac94'),(3,3,1,'__temp_yhocqdfrcrpviiwkinuxracpwnncsallzykg','__temp_yhocqdfrcrpviiwkinuxracpwnncsallzykg',1,'2024-08-11 21:11:08','2024-08-11 21:37:39','4a1dde72-6699-40a2-bb7c-18ad159406fe'),(4,4,1,'__temp_ehkzkfmzduffhagbmwopubcesvzgmnyuaefp',NULL,1,'2024-08-11 21:11:14','2024-08-11 21:11:14','0f73c714-8ac2-43c4-a388-b538257cfde0'),(5,5,1,'this-is-a-slide-heading',NULL,1,'2024-08-11 21:11:45','2024-08-11 21:12:08','ec500645-139d-4c11-836f-88524308081a'),(6,6,1,NULL,NULL,1,'2024-08-11 21:12:20','2024-08-11 21:12:20','efb01554-9ffe-4367-88ce-a8b538011f87'),(7,7,1,'this-is-a-slide-heading',NULL,1,'2024-08-11 21:12:29','2024-08-11 21:12:29','fd379d82-d51e-4a4c-8bac-d9365442c6f1'),(8,8,1,'another-slide',NULL,1,'2024-08-11 21:13:55','2024-08-11 21:13:59','92f14a14-44cd-4a2c-b267-6afda32ebbdc'),(9,9,1,NULL,NULL,1,'2024-08-11 21:14:10','2024-08-11 21:14:10','c4634b2a-31c9-4d4d-b652-6c67ae06cb94'),(10,10,1,'another-slide',NULL,1,'2024-08-11 21:14:16','2024-08-11 21:14:16','078b77c4-8ec1-48fc-9b5b-e9d4670820e1'),(11,11,1,'about-us','about-us',1,'2024-08-11 21:15:00','2024-08-11 21:37:39','a866843a-dfa5-4b0f-9b23-66f3843f5d67'),(12,12,1,NULL,NULL,1,'2024-08-11 21:15:03','2024-08-11 21:15:03','1d168a2e-c269-44a8-9558-5ad3f143ec28'),(13,13,1,'__temp_ecbozmyafiuqmdsqoisuvlejddgskwiseakp',NULL,1,'2024-08-11 21:15:08','2024-08-11 21:15:08','5eee9720-268a-412b-8f04-1250ae3f9e1f'),(14,14,1,NULL,NULL,1,'2024-08-11 21:15:12','2024-08-11 21:15:12','03598c00-69cd-49b7-83c3-a5b62838f999'),(15,15,1,NULL,NULL,1,'2024-08-11 21:15:14','2024-08-11 21:15:14','3355580f-8f24-43ff-ba2f-34b7aafc22a1'),(16,16,1,NULL,NULL,1,'2024-08-11 21:15:20','2024-08-11 21:15:20','50455601-ec3f-425b-a732-de521df057ae'),(17,17,1,NULL,NULL,1,'2024-08-11 21:15:20','2024-08-11 21:15:20','2a97b42b-691a-4db5-bbfa-3fe5aaefaed6'),(18,18,1,NULL,NULL,1,'2024-08-11 21:15:23','2024-08-11 21:15:23','bdc0a7db-fbdd-4462-81ce-f7a5040d75c1'),(19,19,1,NULL,NULL,1,'2024-08-11 21:15:23','2024-08-11 21:15:23','f8c66c80-c41c-45ce-88b3-e988c4f4bf59'),(20,20,1,NULL,NULL,1,'2024-08-11 21:15:32','2024-08-11 21:15:32','9158497d-f973-4941-82da-584c74ab6285'),(21,21,1,NULL,NULL,1,'2024-08-11 21:15:32','2024-08-11 21:15:32','d362800f-edb0-40d0-b109-26d0ddc5f5fc'),(22,22,1,'about-us','general-pages/about-us',1,'2024-08-11 21:15:32','2024-08-11 21:15:32','b6ad727a-2dac-4cc5-8be4-ed017efa81c3'),(23,23,1,NULL,NULL,1,'2024-08-11 21:15:32','2024-08-11 21:15:32','f46e4dfa-7ad8-491e-bf6e-47bba87c832d'),(24,24,1,NULL,NULL,1,'2024-08-11 21:15:33','2024-08-11 21:15:33','9e6daa4a-7f58-4d57-a1f0-a0f59107023e');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (3,1,NULL,1,1,'2024-08-11 21:11:08',NULL,NULL,'2024-08-11 21:11:08','2024-08-11 21:11:08'),(4,2,NULL,3,1,'2024-08-11 21:11:14',NULL,NULL,'2024-08-11 21:11:14','2024-08-11 21:11:14'),(5,2,NULL,3,1,'2024-08-11 21:12:00',NULL,NULL,'2024-08-11 21:11:45','2024-08-11 21:12:29'),(7,2,NULL,3,1,'2024-08-11 21:12:00',NULL,NULL,'2024-08-11 21:12:29','2024-08-11 21:12:29'),(8,2,NULL,3,1,'2024-08-11 21:14:00',NULL,NULL,'2024-08-11 21:13:55','2024-08-11 21:14:16'),(10,2,NULL,3,1,'2024-08-11 21:14:00',NULL,NULL,'2024-08-11 21:14:16','2024-08-11 21:14:16'),(11,1,NULL,1,1,'2024-08-11 21:15:00',NULL,NULL,'2024-08-11 21:15:00','2024-08-11 21:15:00'),(13,2,NULL,3,1,'2024-08-11 21:15:08',NULL,NULL,'2024-08-11 21:15:08','2024-08-11 21:15:08'),(22,1,NULL,1,1,'2024-08-11 21:15:00',NULL,NULL,'2024-08-11 21:15:32','2024-08-11 21:15:32');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-08-11 21:04:00','2024-08-11 21:04:00',NULL,'5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416'),(2,1,2,'Image Slider','imageSlider',1,'site',NULL,NULL,'site',NULL,0,2,'2024-08-11 21:04:41','2024-08-11 21:04:41','2024-08-11 21:08:03','52edef84-8f2a-4e51-b829-b8eba781389e'),(3,2,5,'Default','default',1,'site',NULL,NULL,'site',NULL,0,1,'2024-08-11 21:07:44','2024-08-11 21:11:40',NULL,'bcdc3596-7cb4-4995-924b-59807feb5131');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2024-08-11 20:58:49','2024-08-11 20:58:49',NULL,'99a7252c-81ab-4778-b4ec-2f9bbc2381aa');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (1,3,3,2,0,0,'2024-08-11 21:06:58','2024-08-11 21:06:58','f7bfa8d9-ab38-4afa-a990-4f28ba4c1a9f'),(3,5,7,5,0,1,'2024-08-11 21:11:40','2024-08-11 21:11:40','dbd6ff16-b2f7-4980-be72-aa716e381e94'),(4,5,7,6,0,2,'2024-08-11 21:11:40','2024-08-11 21:11:40','42a67cd2-695c-4486-a26b-b9a39eba9909'),(5,4,8,3,0,0,'2024-08-11 21:14:46','2024-08-11 21:14:46','d801f044-709b-401c-8785-491afc7dca11'),(6,1,9,1,0,1,'2024-08-11 21:14:57','2024-08-11 21:14:57','32b3bdac-f362-424b-973e-c6a0ac943ee3');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2024-08-11 21:04:00','2024-08-11 21:04:00',NULL,'760dba6a-b54d-44ba-991c-bac2d73b4f49'),(2,'craft\\elements\\Entry','2024-08-11 21:04:41','2024-08-11 21:04:41','2024-08-11 21:08:03','d0b5a727-79df-41a0-8a79-c43b03ac9d17'),(3,'craft\\elements\\MatrixBlock','2024-08-11 21:06:58','2024-08-11 21:06:58',NULL,'c6c3dc97-b48e-4497-a724-96380e6d6d96'),(4,'craft\\elements\\MatrixBlock','2024-08-11 21:06:58','2024-08-11 21:06:58',NULL,'0a55fdb9-7e9c-4d55-8373-feeea624b819'),(5,'craft\\elements\\Entry','2024-08-11 21:07:44','2024-08-11 21:07:44',NULL,'a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c'),(6,'craft\\elements\\Asset','2024-08-11 21:10:12','2024-08-11 21:10:12',NULL,'e7be5fe1-eeaf-4f26-882a-ebf3813a1bab');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (2,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"f3d9437b-5bae-4f19-b944-da83a7f1ab86\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-08-11 21:04:41','2024-08-11 21:04:41','c8f935b0-de76-42c9-8275-cf5519d7fcfa'),(3,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4b79fcef-2904-491d-af7c-a565dc08cce7\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"c127a401-697b-4001-9703-6c3a7d4d50db\"}]',1,'2024-08-11 21:06:58','2024-08-11 21:06:58','bb94b995-3543-4cfa-8b08-eb27e8f20aa0'),(6,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"989bf67c-a0f8-4536-9112-81f420c7a25f\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\",\"attribute\":\"alt\",\"requirable\":true,\"class\":null,\"rows\":null,\"cols\":null,\"name\":null,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4975b590-0d52-45a4-8329-95eb464a9f36\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-08-11 21:10:12','2024-08-11 21:10:12','12f3849a-981e-435d-baa4-e181f77c0c14'),(7,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"0edf4f32-bf69-4ef2-aa9a-a57b5bad42a4\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a682e3c6-fcfe-436d-b88e-58d5cff51af3\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"c5542d7d-f0e2-4f91-996e-f7480b4c4472\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"9f76d336-c1be-4812-9d28-5810f17cbfee\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87\"}]',1,'2024-08-11 21:11:40','2024-08-11 21:11:40','38e8d8ca-544b-4333-a940-d38cada2e2b6'),(8,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4c38b2ed-c1fa-4956-a9d8-2487446a075c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e70b90c6-77b3-4856-ba3a-a0f493151b92\"}]',1,'2024-08-11 21:14:46','2024-08-11 21:14:46','25132844-347a-4c39-9daf-be7aac80e4c6'),(9,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"5345bbf3-752c-4113-892d-6f3955220f68\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a3cb2452-0715-4b06-88e9-70d0d6c14e69\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"251f925a-95d1-42e0-b967-a360c80d963e\"}]',1,'2024-08-11 21:14:57','2024-08-11 21:14:57','5da74c11-8df6-47d9-8135-b3cf5851124e');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,1,'Components','components','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":null,\"maxBlocks\":null,\"contentTable\":\"{{%matrixcontent_components}}\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null}','2024-08-11 21:06:58','2024-08-11 21:14:46','251f925a-95d1-42e0-b967-a360c80d963e'),(2,NULL,'Heading','heading','matrixBlockType:b70797f5-4d17-4cc0-bd38-5e6b988be30a','qnetthbg',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-11 21:06:58','2024-08-11 21:06:58','c127a401-697b-4001-9703-6c3a7d4d50db'),(3,NULL,'Image Slides','imageSlides','matrixBlockType:37c5acdc-b7af-4f15-ba27-e987b659b745',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":\"Add Slide\",\"showSiteMenu\":true,\"sources\":[\"section:d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2024-08-11 21:06:58','2024-08-11 21:14:46','e70b90c6-77b3-4856-ba3a-a0f493151b92'),(4,1,'Text','text','global','gelggtgx',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":500,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-11 21:08:33','2024-08-11 21:08:33','0d9157b8-a8e5-4282-891a-bae441cd7c72'),(5,1,'Full Text','fullText','global','ycuvybxe',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"enlarged\"}','2024-08-11 21:09:16','2024-08-11 21:09:16','c5542d7d-f0e2-4f91-996e-f7480b4c4472'),(6,1,'Image','image','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:a5366d6b-34e0-48a0-bf35-d4f2d7b26522\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:a5366d6b-34e0-48a0-bf35-d4f2d7b26522\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:a5366d6b-34e0-48a0-bf35-d4f2d7b26522\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-08-11 21:10:57','2024-08-11 21:10:57','f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.11.1','4.5.3.0',0,'vzdrlgsgfliz','3@ukuuboaats','2024-08-11 20:58:48','2024-08-11 21:37:38','76a8ca1b-cc5a-4840-a2e4-4fac95f1030c');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (12,11,1,2,0,'2024-08-11 21:15:03','2024-08-11 21:15:03'),(14,11,1,2,0,'2024-08-11 21:15:12','2024-08-11 21:15:12'),(15,11,1,2,0,'2024-08-11 21:15:14','2024-08-11 21:15:14'),(16,11,1,2,0,'2024-08-11 21:15:20','2024-08-11 21:15:20'),(17,11,1,1,0,'2024-08-11 21:15:20','2024-08-11 21:15:20'),(18,11,1,1,0,'2024-08-11 21:15:23','2024-08-11 21:15:23'),(19,11,1,2,0,'2024-08-11 21:15:23','2024-08-11 21:15:23'),(20,11,1,1,NULL,'2024-08-11 21:15:32','2024-08-11 21:15:32'),(21,11,1,2,NULL,'2024-08-11 21:15:32','2024-08-11 21:15:32'),(23,22,1,1,NULL,'2024-08-11 21:15:32','2024-08-11 21:15:32'),(24,22,1,2,NULL,'2024-08-11 21:15:33','2024-08-11 21:15:33');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks_owners` VALUES (12,11,1),(14,11,1),(15,11,1),(16,11,1),(17,11,2),(18,11,1),(19,11,2),(20,11,1),(21,11,2),(23,22,1),(24,22,2);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (1,1,3,'Hero','hero',1,'2024-08-11 21:06:58','2024-08-11 21:06:58','b70797f5-4d17-4cc0-bd38-5e6b988be30a'),(2,1,4,'Image Carousel','imageCarousel',2,'2024-08-11 21:06:58','2024-08-11 21:06:58','37c5acdc-b7af-4f15-ba27-e987b659b745');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_components`
--

LOCK TABLES `matrixcontent_components` WRITE;
/*!40000 ALTER TABLE `matrixcontent_components` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_components` VALUES (1,12,1,'2024-08-11 21:15:03','2024-08-11 21:15:03','37f32053-a8e8-4e6c-853e-0db2aa230415',NULL),(2,14,1,'2024-08-11 21:15:12','2024-08-11 21:15:12','d50b6990-6a6b-4d67-8ea6-cc6090256068',NULL),(3,15,1,'2024-08-11 21:15:14','2024-08-11 21:15:14','93dcecd5-be51-49c6-b686-42ddfe5c6637',NULL),(4,16,1,'2024-08-11 21:15:20','2024-08-11 21:15:20','6bcbe6ca-3889-495f-9c79-8dd0dc09f389',NULL),(5,17,1,'2024-08-11 21:15:20','2024-08-11 21:15:20','da6ec41d-c49a-41a2-9b2a-f92127c1bf9c',NULL),(6,18,1,'2024-08-11 21:15:23','2024-08-11 21:15:23','17aa8f5c-ed86-413d-87a4-9efbd3079917',NULL),(7,19,1,'2024-08-11 21:15:23','2024-08-11 21:15:23','31d64724-68da-400e-b9a5-ffd6e1cbdb4d',NULL),(8,20,1,'2024-08-11 21:15:32','2024-08-11 21:37:39','d53ed320-bc9a-436a-8579-aa92d5e446b1','About Page'),(9,21,1,'2024-08-11 21:15:32','2024-08-11 21:37:39','3737fa9a-dd78-4ce0-83a1-7571467b9e74',NULL),(10,23,1,'2024-08-11 21:15:32','2024-08-11 21:37:39','be8c598f-a126-4c64-aa05-f3df2c823b8d','About Page'),(11,24,1,'2024-08-11 21:15:33','2024-08-11 21:37:39','c794f436-e101-4661-9a46-603b7cd1dfa3',NULL);
/*!40000 ALTER TABLE `matrixcontent_components` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','848f5d94-32f6-43ff-a5c8-2b695ec0324f'),(2,'craft','m210121_145800_asset_indexing_changes','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','08d177b5-50d0-46ca-9b50-0e9ca2d9a60b'),(3,'craft','m210624_222934_drop_deprecated_tables','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','784f8dfe-c750-4914-9448-ff2a96092f11'),(4,'craft','m210724_180756_rename_source_cols','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','5726429d-888a-43db-9f6d-4b2f0105f825'),(5,'craft','m210809_124211_remove_superfluous_uids','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','5020a0eb-18b9-4be4-ba47-44c54b08a854'),(6,'craft','m210817_014201_universal_users','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','fafebbb4-9521-4d52-9c62-255cfd879f9d'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','88e40c59-512a-422c-a03e-0640ea932323'),(8,'craft','m211115_135500_image_transformers','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','62597fdc-b070-46a9-bb34-8e071a71fcd1'),(9,'craft','m211201_131000_filesystems','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','a6c23143-02ce-44a0-a5a2-3169cb6ea582'),(10,'craft','m220103_043103_tab_conditions','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','f53cc405-b290-4cad-a4e4-a5af6a85714b'),(11,'craft','m220104_003433_asset_alt_text','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','682c68e7-d187-42f2-b2ff-862fd2084296'),(12,'craft','m220123_213619_update_permissions','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','83f0f87d-a673-46b5-bb9e-418228ca8ebc'),(13,'craft','m220126_003432_addresses','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','3e0328cd-65bd-439c-ab66-d135b0379f0f'),(14,'craft','m220209_095604_add_indexes','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','b910d3d9-8a04-48dc-8c85-d3f76758d26d'),(15,'craft','m220213_015220_matrixblocks_owners_table','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','26d67c87-b88c-4c96-a255-471da6070807'),(16,'craft','m220214_000000_truncate_sessions','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','ea6bb099-8af1-4018-af78-f32c3cd0aaea'),(17,'craft','m220222_122159_full_names','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','7a7aed4e-0467-45b2-a433-64aa0e31d608'),(18,'craft','m220223_180559_nullable_address_owner','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','b6fa0128-f1d4-4596-add3-89f9c161b2d5'),(19,'craft','m220225_165000_transform_filesystems','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','4c0a2912-f82b-435e-bc99-15cf42442612'),(20,'craft','m220309_152006_rename_field_layout_elements','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','5911d69d-bc1c-4423-80fd-ea6b03575480'),(21,'craft','m220314_211928_field_layout_element_uids','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','30cf621a-95ed-4a0d-a112-7c26e6873156'),(22,'craft','m220316_123800_transform_fs_subpath','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','49a355fe-c2b3-42c4-8d6b-acaee88cfca3'),(23,'craft','m220317_174250_release_all_jobs','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','ae59eba9-ab6b-40eb-8650-cb14606e8b56'),(24,'craft','m220330_150000_add_site_gql_schema_components','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','856dc7c2-03f1-4871-b15e-7b9135dc11ec'),(25,'craft','m220413_024536_site_enabled_string','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','3e9cc2c0-c485-4c51-8e24-732f1ddd22cc'),(26,'craft','m221027_160703_add_image_transform_fill','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','9e1476e2-fb85-4339-b912-0c9b6a47cfed'),(27,'craft','m221028_130548_add_canonical_id_index','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','14db2d89-92ea-43ae-b400-4dddce038a9a'),(28,'craft','m221118_003031_drop_element_fks','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','35662c54-2114-4b81-92a8-12c5225b44d2'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','21df6bcd-e4de-44c7-abba-85fddf2045c4'),(30,'craft','m230226_013114_drop_plugin_license_columns','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','f98fca78-7ba0-4fba-8989-3bb050def567'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','f5f753cb-8a71-4c3f-b65d-dec724fc03df'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','7aa7c18b-0253-4ba3-ad52-2f547b8fb546'),(33,'craft','m230710_162700_element_activity','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','f0476fef-92b0-4a81-aa54-cc747fa6cb94'),(34,'craft','m230820_162023_fix_cache_id_type','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','7547c07e-505b-4eeb-bd1b-ce78060028c3'),(35,'craft','m230826_094050_fix_session_id_type','2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 20:58:49','69a625fd-e141-43e4-8287-15fd701cb9b6');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1723412258'),('email.fromEmail','\"sample@email.com\"'),('email.fromName','\"Craft Practice\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elementCondition','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.autocapitalize','true'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.autocomplete','false'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.autocorrect','true'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.class','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.disabled','false'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.elementCondition','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.id','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.inputType','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.instructions','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.label','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.max','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.min','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.name','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.orientation','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.placeholder','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.readonly','false'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.requirable','false'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.size','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.step','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.tip','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.title','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.uid','\"5345bbf3-752c-4113-892d-6f3955220f68\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.userCondition','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.warning','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.0.width','100'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.elementCondition','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.fieldUid','\"251f925a-95d1-42e0-b967-a360c80d963e\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.instructions','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.label','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.required','false'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.tip','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.uid','\"a3cb2452-0715-4b06-88e9-70d0d6c14e69\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.userCondition','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.warning','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.elements.1.width','100'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.name','\"Content\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.uid','\"5da74c11-8df6-47d9-8135-b3cf5851124e\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.fieldLayouts.760dba6a-b54d-44ba-991c-bac2d73b4f49.tabs.0.userCondition','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.handle','\"default\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.hasTitleField','true'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.name','\"Default\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.section','\"be11218f-d920-4770-854e-c1366c1566a6\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.showStatusField','true'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.slugTranslationKeyFormat','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.slugTranslationMethod','\"site\"'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.sortOrder','1'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.titleFormat','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.titleTranslationKeyFormat','null'),('entryTypes.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416.titleTranslationMethod','\"site\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elementCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.autocapitalize','true'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.autocomplete','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.autocorrect','true'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.class','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.disabled','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.elementCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.id','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.inputType','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.instructions','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.label','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.max','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.min','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.name','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.orientation','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.placeholder','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.readonly','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.requirable','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.size','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.step','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.tip','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.title','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.uid','\"0edf4f32-bf69-4ef2-aa9a-a57b5bad42a4\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.userCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.warning','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.0.width','100'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.elementCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.fieldUid','\"c5542d7d-f0e2-4f91-996e-f7480b4c4472\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.instructions','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.label','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.required','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.tip','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.uid','\"a682e3c6-fcfe-436d-b88e-58d5cff51af3\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.userCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.warning','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.1.width','100'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.elementCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.fieldUid','\"f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.instructions','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.label','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.required','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.tip','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.uid','\"9f76d336-c1be-4812-9d28-5810f17cbfee\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.userCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.warning','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.elements.2.width','100'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.name','\"Content\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.uid','\"38e8d8ca-544b-4333-a940-d38cada2e2b6\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.fieldLayouts.a5a5cbac-bbcf-4ce4-8824-ac92ee387d7c.tabs.0.userCondition','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.handle','\"default\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.hasTitleField','true'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.name','\"Default\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.section','\"d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.showStatusField','false'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.slugTranslationKeyFormat','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.slugTranslationMethod','\"site\"'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.sortOrder','1'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.titleFormat','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.titleTranslationKeyFormat','null'),('entryTypes.bcdc3596-7cb4-4995-924b-59807feb5131.titleTranslationMethod','\"site\"'),('fieldGroups.99a7252c-81ab-4778-b4ec-2f9bbc2381aa.name','\"Common\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.columnSuffix','\"gelggtgx\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.contentColumnType','\"text\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.fieldGroup','\"99a7252c-81ab-4778-b4ec-2f9bbc2381aa\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.handle','\"text\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.instructions','null'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.name','\"Text\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.searchable','false'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.byteLimit','null'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.charLimit','500'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.code','false'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.columnType','null'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.initialRows','4'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.multiline','false'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.placeholder','null'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.settings.uiMode','\"normal\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.translationKeyFormat','null'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.translationMethod','\"none\"'),('fields.0d9157b8-a8e5-4282-891a-bae441cd7c72.type','\"craft\\\\fields\\\\PlainText\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.columnSuffix','null'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.contentColumnType','\"string\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.fieldGroup','\"99a7252c-81ab-4778-b4ec-2f9bbc2381aa\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.handle','\"components\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.instructions','null'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.name','\"Components\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.searchable','false'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.settings.contentTable','\"{{%matrixcontent_components}}\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.settings.maxBlocks','null'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.settings.minBlocks','null'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.settings.propagationKeyFormat','null'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.settings.propagationMethod','\"all\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.translationKeyFormat','null'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.translationMethod','\"site\"'),('fields.251f925a-95d1-42e0-b967-a360c80d963e.type','\"craft\\\\fields\\\\Matrix\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.columnSuffix','\"ycuvybxe\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.contentColumnType','\"text\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.fieldGroup','\"99a7252c-81ab-4778-b4ec-2f9bbc2381aa\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.handle','\"fullText\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.instructions','null'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.name','\"Full Text\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.searchable','false'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.byteLimit','null'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.charLimit','null'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.code','false'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.columnType','null'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.initialRows','4'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.multiline','true'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.placeholder','null'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.settings.uiMode','\"enlarged\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.translationKeyFormat','null'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.translationMethod','\"none\"'),('fields.c5542d7d-f0e2-4f91-996e-f7480b4c4472.type','\"craft\\\\fields\\\\PlainText\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.columnSuffix','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.contentColumnType','\"string\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.fieldGroup','\"99a7252c-81ab-4778-b4ec-2f9bbc2381aa\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.handle','\"image\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.instructions','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.name','\"Image\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.searchable','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.allowedKinds.0','\"image\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.allowSelfRelations','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.allowSubfolders','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.allowUploads','true'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.branchLimit','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.defaultUploadLocationSource','\"volume:a5366d6b-34e0-48a0-bf35-d4f2d7b26522\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.defaultUploadLocationSubpath','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.localizeRelations','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.maintainHierarchy','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.maxRelations','1'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.minRelations','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.previewMode','\"full\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.restrictedDefaultUploadSubpath','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.restrictedLocationSource','\"volume:a5366d6b-34e0-48a0-bf35-d4f2d7b26522\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.restrictedLocationSubpath','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.restrictFiles','true'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.restrictLocation','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.selectionLabel','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.showSiteMenu','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.showUnpermittedFiles','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.showUnpermittedVolumes','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.sources.0','\"volume:a5366d6b-34e0-48a0-bf35-d4f2d7b26522\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.targetSiteId','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.validateRelatedElements','false'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.settings.viewMode','\"large\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.translationKeyFormat','null'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.translationMethod','\"site\"'),('fields.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87.type','\"craft\\\\fields\\\\Assets\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"assets/media\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"@webroot/assets/media\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.field','\"251f925a-95d1-42e0-b967-a360c80d963e\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elementCondition','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.fieldUid','\"e70b90c6-77b3-4856-ba3a-a0f493151b92\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.label','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.required','false'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.tip','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.uid','\"4c38b2ed-c1fa-4956-a9d8-2487446a075c\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.warning','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.elements.0.width','100'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.name','\"Content\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.uid','\"25132844-347a-4c39-9daf-be7aac80e4c6\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fieldLayouts.0a55fdb9-7e9c-4d55-8373-feeea624b819.tabs.0.userCondition','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.columnSuffix','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.contentColumnType','\"string\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.fieldGroup','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.handle','\"imageSlides\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.instructions','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.name','\"Image Slides\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.searchable','false'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.allowSelfRelations','false'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.branchLimit','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.localizeRelations','false'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.maintainHierarchy','false'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.maxRelations','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.minRelations','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.selectionLabel','\"Add Slide\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.showSiteMenu','true'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.sources.0','\"section:d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.targetSiteId','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.validateRelatedElements','false'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.settings.viewMode','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.translationKeyFormat','null'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.translationMethod','\"site\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.fields.e70b90c6-77b3-4856-ba3a-a0f493151b92.type','\"craft\\\\fields\\\\Entries\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.handle','\"imageCarousel\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.name','\"Image Carousel\"'),('matrixBlockTypes.37c5acdc-b7af-4f15-ba27-e987b659b745.sortOrder','2'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.field','\"251f925a-95d1-42e0-b967-a360c80d963e\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elementCondition','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.fieldUid','\"c127a401-697b-4001-9703-6c3a7d4d50db\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.label','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.required','false'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.tip','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.uid','\"4b79fcef-2904-491d-af7c-a565dc08cce7\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.warning','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.elements.0.width','100'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.name','\"Content\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.uid','\"bb94b995-3543-4cfa-8b08-eb27e8f20aa0\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fieldLayouts.c6c3dc97-b48e-4497-a724-96380e6d6d96.tabs.0.userCondition','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.columnSuffix','\"qnetthbg\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.contentColumnType','\"text\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.fieldGroup','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.handle','\"heading\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.instructions','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.name','\"Heading\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.searchable','false'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.byteLimit','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.charLimit','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.code','false'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.columnType','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.initialRows','4'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.multiline','false'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.placeholder','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.settings.uiMode','\"normal\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.translationKeyFormat','null'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.translationMethod','\"none\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.fields.c127a401-697b-4001-9703-6c3a7d4d50db.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.handle','\"hero\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.name','\"Hero\"'),('matrixBlockTypes.b70797f5-4d17-4cc0-bd38-5e6b988be30a.sortOrder','1'),('meta.__names__.0d9157b8-a8e5-4282-891a-bae441cd7c72','\"Text\"'),('meta.__names__.251f925a-95d1-42e0-b967-a360c80d963e','\"Components\"'),('meta.__names__.378b0571-ea43-402e-a2fd-bbc409efb64f','\"Craft Practice\"'),('meta.__names__.37c5acdc-b7af-4f15-ba27-e987b659b745','\"Image Carousel\"'),('meta.__names__.3ca78487-12ad-49f0-92bf-f2873d37758e','\"Craft Practice\"'),('meta.__names__.5ca2fdcd-a4ca-418d-8a25-a4f6a0a27416','\"Default\"'),('meta.__names__.99a7252c-81ab-4778-b4ec-2f9bbc2381aa','\"Common\"'),('meta.__names__.a5366d6b-34e0-48a0-bf35-d4f2d7b26522','\"Images\"'),('meta.__names__.b70797f5-4d17-4cc0-bd38-5e6b988be30a','\"Hero\"'),('meta.__names__.bcdc3596-7cb4-4995-924b-59807feb5131','\"Default\"'),('meta.__names__.be11218f-d920-4770-854e-c1366c1566a6','\"General Pages\"'),('meta.__names__.c127a401-697b-4001-9703-6c3a7d4d50db','\"Heading\"'),('meta.__names__.c5542d7d-f0e2-4f91-996e-f7480b4c4472','\"Full Text\"'),('meta.__names__.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1','\"Image Slides\"'),('meta.__names__.e70b90c6-77b3-4856-ba3a-a0f493151b92','\"Image Slides\"'),('meta.__names__.f7ae64d3-2ec5-4d96-96d0-877f7a9c8c87','\"Image\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.defaultPlacement','\"end\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.enableVersioning','true'),('sections.be11218f-d920-4770-854e-c1366c1566a6.handle','\"generalPages\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.name','\"General Pages\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.propagationMethod','\"all\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.enabledByDefault','true'),('sections.be11218f-d920-4770-854e-c1366c1566a6.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.hasUrls','true'),('sections.be11218f-d920-4770-854e-c1366c1566a6.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.template','\"pages/generalPages.twig\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.uriFormat','\"{parent.uri}/{slug}\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.structure.maxLevels','null'),('sections.be11218f-d920-4770-854e-c1366c1566a6.structure.uid','\"3dede275-963c-43d6-9611-81fafd453f73\"'),('sections.be11218f-d920-4770-854e-c1366c1566a6.type','\"structure\"'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.defaultPlacement','\"end\"'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.enableVersioning','true'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.handle','\"imageSlides\"'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.name','\"Image Slides\"'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.propagationMethod','\"all\"'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.enabledByDefault','true'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.hasUrls','false'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.template','null'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.siteSettings.378b0571-ea43-402e-a2fd-bbc409efb64f.uriFormat','null'),('sections.d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1.type','\"channel\"'),('siteGroups.3ca78487-12ad-49f0-92bf-f2873d37758e.name','\"Craft Practice\"'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.handle','\"default\"'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.hasUrls','true'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.language','\"en-US\"'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.name','\"Craft Practice\"'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.primary','true'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.siteGroup','\"3ca78487-12ad-49f0-92bf-f2873d37758e\"'),('sites.378b0571-ea43-402e-a2fd-bbc409efb64f.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Craft Practice\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elementCondition','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.autocapitalize','true'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.autocomplete','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.autocorrect','true'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.class','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.disabled','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.elementCondition','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.id','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.inputType','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.instructions','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.label','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.max','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.min','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.name','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.orientation','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.placeholder','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.readonly','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.requirable','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.size','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.step','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.tip','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.title','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.uid','\"989bf67c-a0f8-4536-9112-81f420c7a25f\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.userCondition','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.warning','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.0.width','100'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.attribute','\"alt\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.class','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.cols','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.disabled','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.elementCondition','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.id','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.instructions','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.label','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.name','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.orientation','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.placeholder','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.readonly','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.requirable','true'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.required','false'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.rows','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.tip','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.title','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.uid','\"4975b590-0d52-45a4-8329-95eb464a9f36\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.userCondition','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.warning','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.elements.1.width','100'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.name','\"Content\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.uid','\"12f3849a-981e-435d-baa4-e181f77c0c14\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fieldLayouts.e7be5fe1-eeaf-4f26-882a-ebf3813a1bab.tabs.0.userCondition','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.fs','\"uploads\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.handle','\"images\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.name','\"Images\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.sortOrder','1'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.titleTranslationKeyFormat','null'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.titleTranslationMethod','\"site\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.transformFs','\"uploads\"'),('volumes.a5366d6b-34e0-48a0-bf35-d4f2d7b26522.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (1,6,5,NULL,6,1,'2024-08-11 21:12:20','2024-08-11 21:12:20','140937c8-3a33-4333-9ba8-4e2323c119a5'),(2,6,7,NULL,6,1,'2024-08-11 21:12:29','2024-08-11 21:12:29','d6234bea-3455-4b96-9200-48e09b594f44'),(3,6,8,NULL,9,1,'2024-08-11 21:14:11','2024-08-11 21:14:11','b13ef9f8-103c-4ce2-8ccd-1a291130dd8f'),(4,6,10,NULL,9,1,'2024-08-11 21:14:16','2024-08-11 21:14:16','6cf4de38-9765-47f9-a78a-a56e9e864384'),(5,3,14,NULL,5,1,'2024-08-11 21:15:12','2024-08-11 21:15:12','49f2cc0b-3efc-4de4-a9c8-159e0099e372'),(6,3,15,NULL,5,1,'2024-08-11 21:15:14','2024-08-11 21:15:14','23b210c2-7de2-4165-aa8c-6eedef78a954'),(7,3,15,NULL,8,2,'2024-08-11 21:15:14','2024-08-11 21:15:14','197dfcbe-082e-4368-8c31-50062328e382'),(8,3,16,NULL,5,1,'2024-08-11 21:15:20','2024-08-11 21:15:20','59bc7a93-4822-477f-b285-a7c3aedcf1be'),(9,3,16,NULL,8,2,'2024-08-11 21:15:20','2024-08-11 21:15:20','54125c19-220f-4a52-bb05-860a5110e2d4'),(10,3,19,NULL,5,1,'2024-08-11 21:15:23','2024-08-11 21:15:23','caf5f91d-3191-47f5-ad20-5e6e194b30cd'),(11,3,19,NULL,8,2,'2024-08-11 21:15:23','2024-08-11 21:15:23','7b9758f8-9b44-420b-ab5c-7e73934da4ee'),(12,3,21,NULL,5,1,'2024-08-11 21:15:32','2024-08-11 21:15:32','85a68ccb-1e3e-4229-bee1-fdc7dfd19df1'),(13,3,21,NULL,8,2,'2024-08-11 21:15:32','2024-08-11 21:15:32','10791870-b830-4103-849a-fe0dca982551'),(14,3,24,NULL,5,1,'2024-08-11 21:15:33','2024-08-11 21:15:33','03178017-9877-4881-9a69-50f314544813'),(15,3,24,NULL,8,2,'2024-08-11 21:15:33','2024-08-11 21:15:33','e51bfdd9-4a4a-4c6a-8773-89841b9dfaae');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,5,1,1,''),(2,8,1,1,''),(3,11,1,1,''),(4,20,1,1,NULL),(5,21,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' sample email com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' nath sdev '),(3,'slug',0,1,' temp yhocqdfrcrpviiwkinuxracpwnncsallzykg '),(3,'title',0,1,''),(4,'slug',0,1,' temp ehkzkfmzduffhagbmwopubcesvzgmnyuaefp '),(4,'title',0,1,''),(5,'slug',0,1,' this is a slide heading '),(5,'title',0,1,' this is a slide heading '),(6,'alt',0,1,''),(6,'extension',0,1,' jpeg '),(6,'filename',0,1,' 1369159 jpeg '),(6,'kind',0,1,' image '),(6,'slug',0,1,''),(6,'title',0,1,' 1369159 '),(8,'slug',0,1,' another slide '),(8,'title',0,1,' another slide '),(9,'alt',0,1,''),(9,'extension',0,1,' png '),(9,'filename',0,1,' 1368925 png '),(9,'kind',0,1,' image '),(9,'slug',0,1,''),(9,'title',0,1,' 1368925 '),(11,'slug',0,1,' about us '),(11,'title',0,1,' about us '),(13,'slug',0,1,' temp ecbozmyafiuqmdsqoisuvlejddgskwiseakp '),(13,'title',0,1,''),(20,'slug',0,1,''),(21,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,1,'General Pages','generalPages','structure',1,'all','end',NULL,'2024-08-11 21:04:00','2024-08-11 21:04:00',NULL,'be11218f-d920-4770-854e-c1366c1566a6'),(2,NULL,'Image Slides','imageSlides','channel',1,'all','end',NULL,'2024-08-11 21:07:44','2024-08-11 21:07:44',NULL,'d8b4fdc3-e87f-4bd9-bb3c-1e0d19ab54d1');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'{parent.uri}/{slug}','pages/generalPages.twig',1,'2024-08-11 21:04:00','2024-08-11 21:37:38','8b7195d9-b344-4645-a50d-fd345227fdce'),(2,2,1,0,NULL,NULL,1,'2024-08-11 21:07:44','2024-08-11 21:07:44','ae838896-7568-4224-ad9f-023300abcf5e');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Craft Practice','2024-08-11 20:58:49','2024-08-11 20:58:49',NULL,'3ca78487-12ad-49f0-92bf-f2873d37758e');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','Craft Practice','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-08-11 20:58:49','2024-08-11 20:58:49',NULL,'378b0571-ea43-402e-a2fd-bbc409efb64f');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,6,0,'2024-08-11 21:05:17','2024-08-11 21:15:38','ba14c0a8-8e53-4e4c-9938-096f7efe52d6'),(3,1,3,1,2,3,1,'2024-08-11 21:11:08','2024-08-11 21:15:38','1d0814f5-f178-486f-bcd5-97ab5a91e69e'),(4,1,11,1,4,5,1,'2024-08-11 21:15:00','2024-08-11 21:15:38','a06b8e62-3ab9-4b6a-acdc-b5296734e643');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2024-08-11 21:04:00','2024-08-11 21:04:00',NULL,'3dede275-963c-43d6-9611-81fafd453f73');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'nath-sdev',NULL,NULL,NULL,'sample@email.com','$2y$13$OQmqL7sjar25mYcsyTsZbu5OdrAQJkb73FLJVOYtszdzwJsEna6d6','2024-08-11 21:00:03',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-08-11 20:58:49','2024-08-11 20:58:49','2024-08-11 21:00:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images','','2024-08-11 21:10:12','2024-08-11 21:10:12','e25e364d-c34b-4f40-b16a-8a468ba3bd97'),(2,NULL,NULL,'Temporary filesystem',NULL,'2024-08-11 21:12:13','2024-08-11 21:12:13','5381775b-f8a6-41e5-a294-b841c8c01c79'),(3,2,NULL,'user_1','user_1/','2024-08-11 21:12:13','2024-08-11 21:12:13','bb1a94c9-19ef-46d1-b1d4-5ced7840f5c1');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,6,'Images','images','uploads','uploads','','site',NULL,1,'2024-08-11 21:10:12','2024-08-11 21:10:12',NULL,'a5366d6b-34e0-48a0-bf35-d4f2d7b26522');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2024-08-11 21:00:03','2024-08-11 21:00:03','783e61ca-2893-4eb5-9781-6e1315fe3371'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-08-11 21:00:03','2024-08-11 21:00:03','d7d30ed0-76f8-47ef-b574-2697ee4886ad'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-08-11 21:00:03','2024-08-11 21:00:03','ce78a2aa-f4f6-45ed-a497-e41822393762'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2024-08-11 21:00:03','2024-08-11 21:00:03','404cf111-1747-486f-b3f0-3e6b5551e1ec');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-11 21:38:55
